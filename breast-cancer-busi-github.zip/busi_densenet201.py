# BUSI Breast Cancer Classification - DenseNet201
import os, random
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms, models
from torch.utils.data import DataLoader, Subset
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, roc_curve, auc
from sklearn.preprocessing import label_binarize
from sklearn.manifold import TSNE

DATA_DIR = "/content/Untitled Folder"  # Change this path
RESULTS_DIR = "/content/BUSI_results"
IMAGE_SIZE, BATCH_SIZE, NUM_EPOCHS = 224, 32, 10
LEARNING_RATE, RANDOM_SEED = 1e-4, 42
os.makedirs(RESULTS_DIR, exist_ok=True)

def seed_everything(seed=42):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
seed_everything(RANDOM_SEED)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device:", device)

train_tfms = transforms.Compose([
    transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
    transforms.RandomHorizontalFlip(0.5),
    transforms.RandomRotation(15),
    transforms.ColorJitter(brightness=0.15, contrast=0.15),
    transforms.ToTensor(),
    transforms.Normalize([0.485,0.456,0.406],[0.229,0.224,0.225])
])
val_tfms = transforms.Compose([
    transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
    transforms.ToTensor(),
    transforms.Normalize([0.485,0.456,0.406],[0.229,0.224,0.225])
])

base = datasets.ImageFolder(DATA_DIR)
classes, labels = base.classes, np.array(base.targets)
n_classes = len(classes)
print("Classes:", classes, "| Images:", len(base))

idx = np.arange(len(base))
train_idx, val_idx = train_test_split(
    idx, test_size=0.20, random_state=RANDOM_SEED, stratify=labels
)
train_full = datasets.ImageFolder(DATA_DIR, transform=train_tfms)
val_full = datasets.ImageFolder(DATA_DIR, transform=val_tfms)
train_ds, val_ds = Subset(train_full, train_idx), Subset(val_full, val_idx)

train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True, num_workers=2, pin_memory=True)
val_loader = DataLoader(val_ds, batch_size=BATCH_SIZE, shuffle=False, num_workers=2, pin_memory=True)

try:
    model = models.densenet201(weights=models.DenseNet201_Weights.DEFAULT)
except AttributeError:
    model = models.densenet201(pretrained=True)
model.classifier = nn.Linear(model.classifier.in_features, n_classes)
model.to(device)

criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)

def train_epoch():
    model.train(); loss_sum = correct = total = 0
    for x, y in train_loader:
        x, y = x.to(device), y.to(device)
        optimizer.zero_grad()
        out = model(x)
        loss = criterion(out, y)
        loss.backward(); optimizer.step()
        loss_sum += loss.item()*x.size(0)
        correct += (out.argmax(1)==y).sum().item()
        total += y.size(0)
    return loss_sum/total, correct/total

def evaluate():
    model.eval(); loss_sum = correct = total = 0
    ys, preds, probs = [], [], []
    with torch.no_grad():
        for x, y in val_loader:
            x, y = x.to(device), y.to(device)
            out = model(x); loss = criterion(out,y)
            p = torch.softmax(out,1); pred = out.argmax(1)
            loss_sum += loss.item()*x.size(0)
            correct += (pred==y).sum().item(); total += y.size(0)
            ys.extend(y.cpu().numpy()); preds.extend(pred.cpu().numpy()); probs.extend(p.cpu().numpy())
    return loss_sum/total, correct/total, np.array(ys), np.array(preds), np.array(probs)

best = 0
train_loss, val_loss, train_acc, val_acc = [], [], [], []
best_path = os.path.join(RESULTS_DIR,"best_densenet201_busi.pth")

for ep in range(NUM_EPOCHS):
    tl, ta = train_epoch()
    vl, va, _, _, _ = evaluate()
    train_loss.append(tl); train_acc.append(ta); val_loss.append(vl); val_acc.append(va)
    print(f"Epoch {ep+1}/{NUM_EPOCHS} | Train Loss {tl:.4f} | Train Acc {ta:.4f} | Val Loss {vl:.4f} | Val Acc {va:.4f}")
    if va > best:
        best = va
        torch.save(model.state_dict(), best_path)

model.load_state_dict(torch.load(best_path, map_location=device))
vl, va, y_true, y_pred, y_prob = evaluate()
print("Best validation accuracy:", f"{best:.4f}")

report = classification_report(y_true,y_pred,target_names=classes,digits=4)
print(report)
Path(os.path.join(RESULTS_DIR,"classification_report.txt")).write_text(report)

cm = confusion_matrix(y_true,y_pred)
plt.figure(figsize=(7,6)); sns.heatmap(cm,annot=True,fmt="d",cmap="Blues",xticklabels=classes,yticklabels=classes)
plt.xlabel("Predicted"); plt.ylabel("True"); plt.title("BUSI DenseNet201 Confusion Matrix"); plt.tight_layout()
plt.savefig(os.path.join(RESULTS_DIR,"confusion_matrix.png"),dpi=300); plt.show()

yb = label_binarize(y_true, classes=np.arange(n_classes))
plt.figure(figsize=(8,6))
for i,c in enumerate(classes):
    fpr,tpr,_=roc_curve(yb[:,i],y_prob[:,i])
    plt.plot(fpr,tpr,label=f"{c} (AUC={auc(fpr,tpr):.4f})")
all_fpr=np.unique(np.concatenate([roc_curve(yb[:,i],y_prob[:,i])[0] for i in range(n_classes)]))
mean_tpr=np.zeros_like(all_fpr)
for i in range(n_classes):
    fpr,tpr,_=roc_curve(yb[:,i],y_prob[:,i]); mean_tpr += np.interp(all_fpr,fpr,tpr)
mean_tpr/=n_classes; macro_auc=auc(all_fpr,mean_tpr)
plt.plot(all_fpr,mean_tpr,"--",label=f"Macro-average (AUC={macro_auc:.4f})")
plt.plot([0,1],[0,1],":"); plt.xlabel("False Positive Rate"); plt.ylabel("True Positive Rate")
plt.title("BUSI DenseNet201 ROC"); plt.legend(); plt.grid(alpha=.3); plt.tight_layout()
plt.savefig(os.path.join(RESULTS_DIR,"roc_curve.png"),dpi=300); plt.show()

plt.figure(figsize=(8,6)); plt.plot(train_acc,marker="o",label="Training"); plt.plot(val_acc,marker="o",label="Validation")
plt.xlabel("Epoch"); plt.ylabel("Accuracy"); plt.title("Accuracy"); plt.legend(); plt.grid(alpha=.3); plt.tight_layout()
plt.savefig(os.path.join(RESULTS_DIR,"accuracy_curve.png"),dpi=300); plt.show()

plt.figure(figsize=(8,6)); plt.plot(train_loss,marker="o",label="Training"); plt.plot(val_loss,marker="o",label="Validation")
plt.xlabel("Epoch"); plt.ylabel("Loss"); plt.title("Loss"); plt.legend(); plt.grid(alpha=.3); plt.tight_layout()
plt.savefig(os.path.join(RESULTS_DIR,"loss_curve.png"),dpi=300); plt.show()

extractor = nn.Sequential(model.features,nn.ReLU(inplace=False),nn.AdaptiveAvgPool2d((1,1))).to(device).eval()
features=[]; flabels=[]
with torch.no_grad():
    for x,y in val_loader:
        z=extractor(x.to(device)).flatten(1)
        features.append(z.cpu().numpy()); flabels.append(y.numpy())
features=np.concatenate(features); flabels=np.concatenate(flabels)
np.save(os.path.join(RESULTS_DIR,"busi_features.npy"),features)
np.save(os.path.join(RESULTS_DIR,"busi_labels.npy"),flabels)
np.save(os.path.join(RESULTS_DIR,"busi_probabilities.npy"),y_prob)
np.save(os.path.join(RESULTS_DIR,"busi_predictions.npy"),y_pred)
np.save(os.path.join(RESULTS_DIR,"busi_true_labels.npy"),y_true)

if len(features)>=10:
    rng=np.random.default_rng(RANDOM_SEED)
    sel=rng.choice(len(features),min(1000,len(features)),replace=False)
    perplexity=min(30,max(5,len(sel)//4))
    z2=TSNE(n_components=2,random_state=RANDOM_SEED,perplexity=perplexity,init="pca",learning_rate="auto").fit_transform(features[sel])
    plt.figure(figsize=(9,7))
    for i,c in enumerate(classes):
        m=flabels[sel]==i; plt.scatter(z2[m,0],z2[m,1],label=c,alpha=.7)
    plt.xlabel("t-SNE 1"); plt.ylabel("t-SNE 2"); plt.title("BUSI DenseNet201 Feature Space"); plt.legend(); plt.grid(alpha=.2); plt.tight_layout()
    plt.savefig(os.path.join(RESULTS_DIR,"tsne.png"),dpi=300); plt.show()

Path(os.path.join(RESULTS_DIR,"experiment_summary.txt")).write_text(
    f"BUSI DenseNet201\nClasses: {classes}\nTrain images: {len(train_ds)}\nValidation images: {len(val_ds)}\n"
    f"Best validation accuracy: {best:.4f}\nFinal validation accuracy: {va:.4f}\nMacro ROC-AUC: {macro_auc:.4f}\n"
)
print("Completed. Results:", RESULTS_DIR)
